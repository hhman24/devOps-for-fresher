<template>
  <taskEditor/>
</template>

<script>
  import taskEditor from "../components/taskEditor.vue"

  export default {

    name: "List",
    components: {
      taskEditor,
    }
  }
</script>
